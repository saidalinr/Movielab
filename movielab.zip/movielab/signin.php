<?php
session_start();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Example user: username: admin, password: 1234
    if ($username === 'admin' && $password === '1234') {
        $_SESSION['user_id'] = $username; // Store logged-in user in session
        header("Location: movies.php"); // Redirect to protected page
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login - MovieLab</title>
<style>
body { font-family: Arial; background: #141414; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; }
form { background: #222; padding: 30px; border-radius: 10px; }
input { display: block; margin: 10px 0; padding: 10px; width: 100%; border-radius: 6px; border: none; }
button { background: red; color: white; padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; }
</style>
</head>
<body>

<form method="POST">
<h2>Login</h2>
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Login</button>
<p style="color:red;"><?php echo $error; ?></p>
</form>

</body>
</html>
