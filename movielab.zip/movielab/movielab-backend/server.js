require("dotenv").config();
const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// DB connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "yourpassword",   // change to your MySQL password
  database: "movielab"
});

// Middleware to verify JWT
function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// ✅ Register User
app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  db.query(
    "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
    [name, email, hashedPassword],
    (err, result) => {
      if (err) return res.status(400).json({ error: "Email already exists!" });
      res.json({ message: "User registered successfully!" });
    }
  );
});

// ✅ Login User
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
    if (err || results.length === 0) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    const user = results[0];
    if (await bcrypt.compare(password, user.password)) {
      const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, {
        expiresIn: "1h"
      });
      res.json({ message: "Login successful", token });
    } else {
      res.status(400).json({ error: "Invalid email or password" });
    }
  });
});

// ✅ Get All Movies
app.get("/movies", (req, res) => {
  db.query("SELECT * FROM movies", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// ✅ Add Movie (protected)
app.post("/movies", authenticateToken, (req, res) => {
  const { title, year, duration, poster } = req.body;
  db.query(
    "INSERT INTO movies (title, year, duration, poster) VALUES (?, ?, ?, ?)",
    [title, year, duration, poster],
    (err, result) => {
      if (err) throw err;
      res.json({ message: "Movie added successfully!" });
    }
  );
});

// ✅ Delete Movie (protected)
app.delete("/movies/:id", authenticateToken, (req, res) => {
  db.query("DELETE FROM movies WHERE id = ?", [req.params.id], (err, result) => {
    if (err) throw err;
    res.json({ message: "Movie deleted!" });
  });
});

app.listen(5000, () => console.log("🚀 Server running on http://localhost:5000"));
